Panait Stefan-Andrei 342C2
    Task crypto-attack: Am folosit comanda nc pentru a creea o conexiune catre server, am observat ca primesc inapoi un mesaj care este base64, l-am decodat,
    vad ca este un json cu p, g, A. Din asta si din hint mi-am dat seama ca este vorba de Diffie Hellman, astfel am calculat cheia mea publica, si
    am trimis la server. Primesc alt mesaj pe care il decodez cu base 64, observ ca este json si are msg si salt. Astfel msg este ceea ce trebuie sa
    decodez eu cu shared secret ul aflat din diffie hellman. Decriptez mesajul cu AES tip ECB.

    Task linux-acl: Folosesc un find pentru a vedea fisierele la care am drepturi de citire sau scriere. Observ printre ele un fisier shefie.xo, imi dau seama
    ca acesta este fisierul pe care trebuie sa il analizez. Daca il rulez acesta imi da mesajul "You shall not pass!". Astfel il analizez ca la laborator cu
    strings si ma uit pentru indicii. Observ ca eu trebuie cumva sa ajung sa imi scrie "Ok, I'll show you a magic trick". Astfel vad ca este un strcmp si
    dau argument la rulare mai multe linii din strings care mi s-au parut de interes. Am gasit cu ce facea comparatia si am intrat in partea aceea a codului.
    Astfel imi da fisierul in care este flagul: /usr/share/vim/talent/my.flag: ASCII text. Ma duc la fisier si vad ca nu am permisiuni. Astfel fac un atac de tip
    path hijacking, adaug calea tmp in path imi creez un fisier acolo in care scriu comanda cat pe fisierul de flag.

    Task binary-exploit: Analizez casino cu ghidra, observ ca am 3 functii de interes. In main vad ia varsta, daca esti mai mic decat x nu ai voie sa joci,
    daca te cheama Florin Salam ai mai multi bani. Apoi apeleaza functia loop, in aceasta functie gasesc un array pe care pot sa il abuzez prin buffer overflow
    astfel imi dau seama ca trebuie prin acest buffer overflow sa ajung in functia de win(adresa). Dar problema este ca numarul este random generat care mai apoi
    trebuie sa il dau ca parametru pentru functia win. Astfel trebuie sa fac un buffer overflow care se intoarce inaintea while-ului (080493d7), pentru a primi
    numarul norocos si a face alt bufferoverflow cu numarul norocos dat ca parametru si adresa win(08049256). Astfel compara si obint flagul.