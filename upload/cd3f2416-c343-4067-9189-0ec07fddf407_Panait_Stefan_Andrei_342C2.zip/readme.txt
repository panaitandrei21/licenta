Panait Stefan-Andrei 342C2
    task 0 - rulez sudo ./connect.sh intru, retin # inmate ul meu dau ip a s ma uit la eth 0
    apoi rulez nmap pentru a verifica toate porturile TCP astfel gasesc ip-ul si portul care ruleaza
    apoi rulez webtunnel cu ele si ma conectez in browser la local host.

    task 1 - ma conectez cu student si acel # de la welcome inmate de la inceput, apoi
    caut in sources flagul si il gasesc in inspect elements cu ctrl f dupa Speish

    task 2 - tcpdump pe eth0 gasesc un mesaj your-jail > efectuat cu succes apoi fac nc pe acel port astfel gasesc
    username si parola username=guard&password=04d0abfbc3 ma conectez cu ele. Gasesc flagul la Private Messages

    task 3 - fac un javascript injection ca la laborator in mesajele cu decanul. Pe scurt scriptul cand vede ca username-ul nu este guard
    pun formular ul de change password, si manipulez newpassword si confirmpassword si triggeruiesc submit la final. Dupa care
    ma conectez ca dekhan cu noua parola setata de mine si gasesc flagul in consola.

    task 4 - Conectat ca dekhan, Ma uit in conversatia cu Alexander (DBA) clar este vorba de sql injection. Daca dau select normal observ ca nu pot sa vad
    rektorul. Aici am dat un SELECT * FROM accounts WHERE privilege = 1 ORDER BY --  , asa s-ar scrie in limbaj normal sql (practic face ca urmatoarele interogari
    dupa -- sa nu fie luate in considerare, -- functioneaza ca cometariu deci comentez restul interogarilor)
    Apoi cu aceeasi comanda dau un update dar mai intai imi generez parola in sha pe care folosind injection dau update la password la toti utilizatorii, ma conectez
    ca rektor si flagul este in consola.

    tesk 5 - Am facut requesturi de tip get la cele mai comune nume de branchuri pana cand pe /refs/heads/master primesc inapoi
    un commit hash. Apoi cu acel hash curl /objects/hash pentru obtinerea a ce se afla in el, iar pentru decodificare ma folosesc de
    zlib-flate. Apoi gasesc tree-ul. decodific tree apoi cu git cat-file gasesc hash pentru git_flag repet procesul si dupa uncompress
    primesc flagul. De asemenea am mai gasit un tool pe google cu care poti gasii toate commiturile trebuie doar sa dai uncompress.